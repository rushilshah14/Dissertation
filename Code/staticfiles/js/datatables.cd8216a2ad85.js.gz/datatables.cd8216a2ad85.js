$(document).ready(function() {
  $('#datatables').DataTable({

  });

  var table = $('#datatable').DataTable();

});
$(document).ready(function() {
  $('#datatables1').DataTable({

  });

  var table = $('#datatable1').DataTable();

});
